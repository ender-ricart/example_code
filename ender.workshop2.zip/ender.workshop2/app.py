from banking_pkg import account
# from banking_pkg import operations

def atm_menu(name):
  print("")
  print("          === Automated Teller Machine ===          ")
  print(f"User: {name}")
  print("------------------------------------------")
  print("| 1.    Balance     | 2.    Deposit      |")
  print("------------------------------------------")
  print("------------------------------------------")
  print("| 3.    Withdraw    | 4.    Logout       |")
  print("------------------------------------------")
balance = 0.0

while True:
    print("    === Automated Teller Machine ===    ")
    name = input("Enter name to register:  ")
    pin = input("Create a 4-number PIN:  ")
    if len(name) > 1 and len(name) <= 10 and pin.isalnum() is True and len(pin) == 4:
        print(f"{name}, has been registered with a starting balance of {str(balance)}")
        break
    else:
      print("Please try again. Input does not meet requirements.")

while True:
    print("    === Automated Teller Machine ===    ")
    print("LOGIN")
    name_to_validate = input("Please enter your name: ")
    pin_to_validate = input("Please enter your PIN: ") 
    if name_to_validate.lower() == name.lower() and pin_to_validate == pin:
        print("Login successful!")
        break
    else: 
        if pin_to_validate != pin and (name_to_validate).lower() != (name).lower():
            print("Invalid credentials entered!")

while True:
    atm_menu(name)
    option = input("Choose an option: ")
    if option == "1":
        account.show_balance(balance)
    elif option == "2":
        balance = account.deposit(balance)
    elif option == "3":
        balance = account.withdraw(balance)
    elif option == "4":
        account.logout(name)
        atm_menu(name)
    else:
        print("Invalid option. Please select: 1, 2, 3, or 4.")