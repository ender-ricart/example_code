# We don't import things into account.py for this
# assignment.  And remember that we don't want
# to touch global variables anyway.  We pass information
# in to functions, and read what comes back.

# from app import name


# from banking_pkg import operations
# from banking_pkg import login

def show_balance(balance):
    print (f"Current Balance: {balance} ")

def deposit(balance):
    amount = input("Enter amount to deposit:  ")
    if int(amount) >=0:
        try:
            amount = float(amount)
        except ValueError:
            print("The amount must be a number.")
            deposit(balance)
        else:
            if amount > 0:
                balance = float(amount) + float(balance)
                print(f"Current Balance: {balance}")
                return balance
            else:
                print("Please input a numeric value.")
                deposit(balance)
    else:
        print("Enter a valid number.")

def withdraw(balance):
    amount = input("Enter amount to withdraw:  ")
    if int(amount) >=0:
        try:
            amount = float(amount)
        except ValueError:
            print("The amount must be a number.")
            withdraw(balance)
        else:
            if balance >= 0 and amount <= balance:
                balance = float(balance) - float(amount)
                print(f"Current Balance: {balance}")
                return balance
            elif float(amount) > balance: 
                print(f"You withdrawal amount exceeds your current balance: {balance}.")
                withdraw(balance)
            else:
                print("Invalid entry. Enter numbers only")
                withdraw(balance)  
    else:
        print("Enter a valid number.")

def logout(name):
    print(f"Thank you for banking with ThankBank {name}!")
    